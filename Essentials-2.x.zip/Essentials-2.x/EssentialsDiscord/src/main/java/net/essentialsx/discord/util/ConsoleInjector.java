package net.essentialsx.discord.util;

import com.earth2me.essentials.utils.FormatUtil;
import com.google.common.base.Splitter;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.utils.TimeFormat;
import net.essentialsx.discord.EssentialsDiscord;
import net.essentialsx.discord.JDADiscordService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.Logger;
import org.apache.logging.log4j.core.appender.AbstractAppender;
import org.apache.logging.log4j.core.config.plugins.Plugin;
import org.bukkit.Bukkit;

import java.time.Instant;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.regex.Pattern;

import static com.earth2me.essentials.I18n.tlLiteral;

@Plugin(name = "EssentialsX-ConsoleInjector", category = "Core", elementType = "appender", printObject = true)
public class ConsoleInjector extends AbstractAppender {
    private final static java.util.logging.Logger logger = EssentialsDiscord.getWrappedLogger();

    private final static long QUEUE_PROCESS_PERIOD_SECONDS = 2;
    private final static int QUEUE_CAPACITY = 500;

    private final JDADiscordService jda;
    private final BlockingQueue<String> messageQueue = new ArrayBlockingQueue<>(QUEUE_CAPACITY);
    private final int taskId;
    private boolean removed = false;

    public ConsoleInjector(JDADiscordService jda) {
        super("EssentialsX-ConsoleInjector", null, null, false);
        this.jda = jda;
        ((Logger) LogManager.getRootLogger()).addAppender(this);
        taskId = Bukkit.getScheduler().runTaskTimerAsynchronously(jda.getPlugin(), () -> {
            final StringBuilder buffer = new StringBuilder();
            String curLine;
            while ((curLine = messageQueue.peek()) != null) {
                if (buffer.length() + curLine.length() > Message.MAX_CONTENT_LENGTH - 2) {
                    sendMessage(buffer.toString());
                    buffer.setLength(0);
                    continue;
                }
                buffer.append("\n").append(messageQueue.poll());
            }
            if (buffer.length() != 0) {
                sendMessage(buffer.toString());
            }
        }, 20, 20 * QUEUE_PROCESS_PERIOD_SECONDS).getTaskId();
    }

    private void sendMessage(String content) {
        final WebhookDispatcher webhook = jda.getConsoleWebhook();
        if (webhook == null || webhook.isShutdown()) {
            return;
        }
        webhook.send(jda.getWebhookMessage(content)).exceptionally(e -> {
            logger.severe(tlLiteral("discordErrorWebhook"));
            remove();
            return null;
        });
    }

    @Override
    public void append(LogEvent event) {
        if (event.getLevel().intLevel() > jda.getSettings().getConsoleLogLevel().intLevel()) {
            return;
        }

        // Ansi strip is for normal colors, normal strip is for 1.16 hex color codes as they are not formatted correctly, adventure strip is for magic color char strip
        String entry = FormatUtil.stripPaper(FormatUtil.stripFormat(FormatUtil.stripAnsi(event.getMessage().getFormattedMessage()))).trim();
        if (entry.isEmpty()) {
            return;
        }

        final String[] loggerNameSplit = event.getLoggerName().split("\\.");
        final String loggerName = loggerNameSplit[loggerNameSplit.length - 1].trim();

        if (!loggerName.isEmpty()) {
            entry = "[" + loggerName + "] " + entry;
        }

        if (!jda.getSettings().getConsoleFilters().isEmpty()) {
            for (final Pattern pattern : jda.getSettings().getConsoleFilters()) {
                if (pattern.matcher(entry).find()) {
                    return;
                }
            }
        }

        for (final String line : Splitter.fixedLength(Message.MAX_CONTENT_LENGTH - 50).splitToList(
                MessageUtil.formatMessage(jda.getSettings().getConsoleFormat(),
                        TimeFormat.TIME_LONG.format(Instant.now()),
                        event.getLevel().name(),
                        MessageUtil.sanitizeDiscordMarkdown(entry)))) {

            if (!messageQueue.offer(line)) {
                if (jda.isDebug()) {
                    logger.fine("Console relay queue full, dropping message.");
                }
            }
        }
    }

    public void remove() {
        ((Logger) LogManager.getRootLogger()).removeAppender(this);
        Bukkit.getScheduler().cancelTask(taskId);
        messageQueue.clear();
        if (jda.getConsoleWebhook() != null && !jda.getConsoleWebhook().isShutdown()) {
            jda.getConsoleWebhook().close();
        }
        removed = true;
    }

    public boolean isRemoved() {
        return removed;
    }
}
