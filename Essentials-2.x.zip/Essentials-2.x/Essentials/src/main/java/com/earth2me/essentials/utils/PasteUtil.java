package com.earth2me.essentials.utils;

import com.google.common.base.Charsets;
import com.google.common.io.CharStreams;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import org.checkerframework.checker.nullness.qual.Nullable;

import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.zip.GZIPOutputStream;

public final class PasteUtil {
    private static final String PASTE_URL = "https://pastes.dev/";
    private static final String PASTE_UPLOAD_URL = "https://api.pastes.dev/post";
    private static volatile ExecutorService PASTE_EXECUTOR_SERVICE = Executors.newSingleThreadExecutor();
    private static final Gson GSON = new Gson();

    private PasteUtil() {
    }

    /**
     * Creates an anonymous paste containing the provided files.
     *
     * @param pages The files to include in the paste.
     * @return The result of the paste, including the paste URL and deletion key.
     */
    public static CompletableFuture<PasteResult> createPaste(List<PasteFile> pages) {
        final CompletableFuture<PasteResult> future = new CompletableFuture<>();
        getExecutor().submit(() -> {
            try {
                final HttpURLConnection connection = (HttpURLConnection) new URL(PASTE_UPLOAD_URL).openConnection();
                connection.setRequestMethod("POST");
                connection.setDoInput(true);
                connection.setDoOutput(true);
                connection.setRequestProperty("User-Agent", "EssentialsX plugin");
                connection.setRequestProperty("Content-Type", "text/json");
                connection.setRequestProperty("Content-Encoding", "gzip");
                final JsonObject body = new JsonObject();
                final JsonArray files = new JsonArray();
                for (final PasteFile page : pages) {
                    final JsonObject file = new JsonObject();
                    final JsonObject content = new JsonObject();
                    file.addProperty("name", page.getName());
                    content.addProperty("format", "text");
                    content.addProperty("value", page.getContents());
                    file.add("content", content);
                    files.add(file);
                }
                body.add("files", files);

                try (final OutputStream os = new GZIPOutputStream(connection.getOutputStream())) {
                    os.write(body.toString().getBytes(Charsets.UTF_8));
                }

                if (connection.getResponseCode() >= 400) {
                    future.completeExceptionally(new Error(CharStreams.toString(new InputStreamReader(connection.getErrorStream(), StandardCharsets.UTF_8))));
                    return;
                }

                // Read URL
                final JsonObject object = GSON.fromJson(new InputStreamReader(connection.getInputStream(), Charsets.UTF_8), JsonObject.class);
                final String pasteId = object.get("key").getAsString();
                final String pasteUrl = PASTE_URL + pasteId;
                connection.disconnect();

                final PasteResult result = new PasteResult(pasteId, pasteUrl, null);
                future.complete(result);
            } catch (Exception e) {
                future.completeExceptionally(e);
            }
        });
        return future;
    }

    private static synchronized ExecutorService getExecutor() {
        if (PASTE_EXECUTOR_SERVICE == null || PASTE_EXECUTOR_SERVICE.isShutdown() || PASTE_EXECUTOR_SERVICE.isTerminated()) {
            PASTE_EXECUTOR_SERVICE = Executors.newSingleThreadExecutor();
        }
        return PASTE_EXECUTOR_SERVICE;
    }

    public static synchronized void shutdownExecutor() {
        final ExecutorService exec = PASTE_EXECUTOR_SERVICE;
        if (exec == null) {
            return;
        }
        exec.shutdown();
        try {
            if (!exec.awaitTermination(5, TimeUnit.SECONDS)) {
                exec.shutdownNow();
            }
        } catch (final InterruptedException ignored) {
            exec.shutdownNow();
        }
    }

    public static class PasteFile {
        private final String name;
        private final String contents;

        public PasteFile(final String name, final String contents) {
            this.name = name;
            this.contents = contents;
        }

        public String getName() {
            return name;
        }

        public String getContents() {
            return contents;
        }
    }

    public static class PasteResult {
        private final String pasteId;
        private final String pasteUrl;
        private final @Nullable String deletionKey;

        protected PasteResult(String pasteId, final String pasteUrl, final @Nullable String deletionKey) {
            this.pasteId = pasteId;
            this.pasteUrl = pasteUrl;
            this.deletionKey = deletionKey;
        }

        public String getPasteUrl() {
            return pasteUrl;
        }

        public @Nullable String getDeletionKey() {
            return deletionKey;
        }

        public String getPasteId() {
            return pasteId;
        }
    }

}
