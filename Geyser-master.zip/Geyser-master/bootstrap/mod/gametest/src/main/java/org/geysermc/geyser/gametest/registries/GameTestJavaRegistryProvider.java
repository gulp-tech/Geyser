/*
 * Copyright (c) 2025 GeyserMC. http://geysermc.org
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @author GeyserMC
 * @link https://github.com/GeyserMC/Geyser
 */

package org.geysermc.geyser.gametest.registries;

import net.minecraft.core.LayeredRegistryAccess;
import net.minecraft.network.protocol.configuration.ConfigurationProtocols;
import net.minecraft.server.RegistryLayer;
import net.minecraft.server.network.ConfigurationTask;
import net.minecraft.server.network.config.SynchronizeRegistriesTask;
import org.geysermc.geyser.gametest.mixin.SynchronizeRegistriesTaskAccessor;
import org.geysermc.geyser.gametest.util.NetworkUtil;
import org.geysermc.geyser.registry.java.JavaRegistryProvider;
import org.geysermc.geyser.session.cache.registry.JavaRegistryTagCache;
import org.geysermc.mcprotocollib.network.packet.Packet;
import org.geysermc.mcprotocollib.protocol.packet.common.clientbound.ClientboundUpdateTagsPacket;
import org.geysermc.mcprotocollib.protocol.packet.configuration.clientbound.ClientboundRegistryDataPacket;

import java.util.List;
import java.util.Optional;
import java.util.Set;

public final class GameTestJavaRegistryProvider {

    private GameTestJavaRegistryProvider() {}

    public static JavaRegistryProvider create(LayeredRegistryAccess<RegistryLayer> registries) {
        JavaRegistryTagCache provider = new JavaRegistryTagCache();

        // List.of() is known packs and doesn't matter in this context
        ConfigurationTask synchronizeRegistriesTask = new SynchronizeRegistriesTask(List.of(), registries);

        ((SynchronizeRegistriesTaskAccessor) synchronizeRegistriesTask).invokeSendRegistries(
            packet -> {
                Packet mcpl = NetworkUtil.mojangToGeyserPacket(ConfigurationProtocols.CLIENTBOUND, packet);
                if (mcpl instanceof ClientboundRegistryDataPacket registryDataPacket) {
                    provider.loadRegistryData(registryDataPacket);
                } else if (mcpl instanceof ClientboundUpdateTagsPacket tagsPacket) {
                    provider.loadTags(Optional.empty(), tagsPacket);
                } else {
                    throw new IllegalStateException("Unexpected packet during registry synchronisation: " + mcpl);
                }
            },
            Set.of()
        );

        provider.freeze();

        return provider;
    }
}
